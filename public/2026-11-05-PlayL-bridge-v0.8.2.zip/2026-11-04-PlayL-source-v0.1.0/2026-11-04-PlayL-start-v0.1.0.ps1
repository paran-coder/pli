$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
Write-Host 'PlayL-v0.1.0: http://127.0.0.1:43119'
Write-Host '브릿지를 종료하려면 Ctrl+C를 누르세요.'
& node (Join-Path $PSScriptRoot 'bridge\2026-11-04-server.mjs')
