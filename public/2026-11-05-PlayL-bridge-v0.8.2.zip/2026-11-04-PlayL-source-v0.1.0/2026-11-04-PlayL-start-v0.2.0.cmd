@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js 22 or newer is required.
  pause
  exit /b 1
)
echo PlayL-v0.2.0: http://127.0.0.1:43119
echo Keep this window open. Stop: Ctrl+C
node "%~dp0bridge\2026-11-04-server.mjs"
if errorlevel 1 pause
